//
//  YDAlertLogin.m
//  ydx_login
//
//  Created by meiyue on 2017/11/3.
//  Copyright © 2017年 meiyue. All rights reserved.
//

#import "YDAlertLogin.h"

#define kDFont 18
#define kXFont 15
#define kSpace 20
#define kHSpace 50
#define kTextFieldH  50

@interface YDAlertLogin ()
{
    CGFloat width;
    CGFloat height;
}
@property (nonatomic, strong) UIView * verityView;//
@property (nonatomic, strong) UIView * passView;//

@property (nonatomic, strong) UILabel *verTitleLab;
@property (nonatomic, strong) UITextField *verTelTextField;
@property (nonatomic, strong) UITextField *verCodeTextField;
@property (nonatomic, strong) UIButton *verGetCodeBtn;
@property (nonatomic, strong) UIView *verLine1;
@property (nonatomic, strong) UIView *verLine2;



@property (nonatomic, strong) UILabel *pasTitleLab;
@property (nonatomic, strong) UITextField *pasTelTextField;
@property (nonatomic, strong) UITextField *pasWordTextField;
@property (nonatomic, strong) UIView *pasLine1;
@property (nonatomic, strong) UIView *pasLine2;


@property (nonatomic, strong) UIButton *changeBtn;//切换
@property (nonatomic, strong) UIButton *loginBtn; //登录







@end


@implementation YDAlertLogin


//
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        //[self setup];
        width = frame.size.width;
        height = frame.size.height;
        //self.backgroundColor = [UIColor lightGrayColor];
    }
    return self;
}

- (void)setLoginMode:(LoginMode)loginMode
{
    _loginMode = loginMode;
    
    if (loginMode == LoginModeVerity) {
        [self setupVerity];
    }
    else if (loginMode == LoginModePass){
        [self setupPass];
    }
}

- (void)setupVerity
{
    
    //self.verityView.backgroundColor = [UIColor redColor];
    [self.verityView addSubview:self.verTitleLab];
    [self.verityView addSubview:self.verTelTextField];
    [self.verityView addSubview:self.verLine1];
    [self.verityView addSubview:self.verCodeTextField];
    [self.verityView addSubview:self.verGetCodeBtn];
    [self.verityView addSubview:self.verLine2];

    [self addSubview:self.changeBtn];
    [self addSubview:self.loginBtn];
    
}

- (void)setupPass
{
    //self.passView.backgroundColor = [UIColor yellowColor];
    [self.passView addSubview:self.pasTitleLab];
    [self.passView addSubview:self.pasTelTextField];
    [self.passView addSubview:self.pasLine1];
    [self.passView addSubview:self.pasWordTextField];
    [self.passView addSubview:self.pasLine2];
    
    [self addSubview:self.changeBtn];
    [self addSubview:self.loginBtn];
}

- (void)changeBtnAction:(UIButton *)btn
{
    NSLog(@"--切换--");
    if ([btn.titleLabel.text isEqualToString:@"验证码登录"]) {
        [btn setTitle:@"密码登录" forState:UIControlStateNormal];
        self.loginMode = LoginModePass;
    }
    else
    {
        [btn setTitle:@"验证码登录" forState:UIControlStateNormal];
        self.loginMode = LoginModeVerity;
    }
    
    
}


- (void)loginBtnAction
{
    NSLog(@"--登录--");
}

- (void)getCode:(UIButton *)btn
{
    NSLog(@"--获取验证码--");
}














































#pragma mark --切换和登录按钮
- (UIButton *)changeBtn
{
    if (!_changeBtn) {
        CGFloat btnW = 100;
        _changeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _changeBtn.frame = CGRectMake(kSpace, 180, btnW, 30);
        [_changeBtn setTitle:@"密码登录" forState:UIControlStateNormal];
        [_changeBtn setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
        [_changeBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateHighlighted];
        [_changeBtn addTarget:self action:@selector(changeBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        _changeBtn.titleLabel.font = [UIFont systemFontOfSize:kXFont];
        _changeBtn.layer.borderWidth = 1;
        _changeBtn.layer.borderColor = [UIColor lightGrayColor].CGColor;
        _changeBtn.layer.cornerRadius = 3;
        _changeBtn.layer.masksToBounds = YES;
    }
    return _changeBtn;
}

- (UIButton *)loginBtn
{
    if (!_loginBtn) {
        CGFloat btnW = 160;
        CGFloat btnH = 50;
        _loginBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _loginBtn.frame = CGRectMake((width - btnW)/2, 240, btnW, btnH);
        [_loginBtn setTitle:@"登录" forState:UIControlStateNormal];
        [_loginBtn setTitleColor:[UIColor lightGrayColor] forState:UIControlStateHighlighted];
        _loginBtn.backgroundColor = [UIColor orangeColor];
        [_loginBtn addTarget:self action:@selector(loginBtnAction) forControlEvents:UIControlEventTouchUpInside];
    }
    return _loginBtn;
}





#pragma mark --lazy
- (UIView *)verityView
{
    if (!_verityView) {
        CGRect rect = CGRectMake(0, 0, width, 200);
        _verityView = [[UIView alloc]initWithFrame:rect];
        [self addSubview:_verityView];
    }
    return _verityView;
}

- (UIView *)passView
{
    if (!_passView) {
        CGRect rect = CGRectMake(0, 0, width, 200);
        _passView = [[UIView alloc]initWithFrame:rect];
        [self addSubview:_passView];
    }
    return _passView;
}



#pragma mark --密码登录

- (UILabel *)pasTitleLab
{
    if (!_pasTitleLab) {
        CGRect rect = CGRectMake(0, 20, width, 20);
        _pasTitleLab = [[UILabel alloc]initWithFrame:rect];
        _pasTitleLab.textAlignment = NSTextAlignmentCenter;
        _pasTitleLab.font = [UIFont systemFontOfSize:kDFont];
        _pasTitleLab.text = @"密码登录";
    }
    return _pasTitleLab;
}

- (UITextField *)pasTelTextField
{
    if (!_pasTelTextField) {
        CGRect rect = CGRectMake(kSpace, CGRectGetMaxY(_pasTitleLab.frame) + kSpace, width - kSpace *2, kTextFieldH);
        _pasTelTextField = [[UITextField alloc]initWithFrame:rect];
        _pasTelTextField.borderStyle = UITextBorderStyleNone;
        _pasTelTextField.placeholder = @"手机号";
    }
    return _pasTelTextField;
}

- (UIView *)pasLine1
{
    if (!_pasLine1) {
        CGRect rect = CGRectMake(kSpace, CGRectGetMaxY(_pasTelTextField.frame), width - kSpace *2, 1);
        _pasLine1 = [[UIView alloc]initWithFrame:rect];
        _pasLine1.backgroundColor = [UIColor groupTableViewBackgroundColor];
    }
    return _pasLine1;
}

- (UITextField *)pasWordTextField
{
    if (!_pasWordTextField) {
        CGRect rect = CGRectMake(kSpace, CGRectGetMaxY(_pasLine1.frame), width - kSpace*2, kTextFieldH);
        _pasWordTextField = [[UITextField alloc]initWithFrame:rect];
        _pasWordTextField.borderStyle = UITextBorderStyleNone;
        _pasWordTextField.placeholder = @"密码";
    }
    return _pasWordTextField;
}

- (UIView *)pasLine2
{
    if (!_pasLine2) {
        CGRect rect =  CGRectMake(kSpace, CGRectGetMaxY(_pasWordTextField.frame), width - kSpace *2, 1);
        _pasLine2 = [[UIView alloc]initWithFrame:rect];
        _pasLine2.backgroundColor = [UIColor groupTableViewBackgroundColor];
    }
    return _pasLine2;
}





#pragma mark --验证码登录
- (UILabel *)verTitleLab
{
    if (!_verTitleLab) {
        CGRect rect = CGRectMake(0, 20, width, 20);
        _verTitleLab = [[UILabel alloc]initWithFrame:rect];
        _verTitleLab.textAlignment = NSTextAlignmentCenter;
        _verTitleLab.font = [UIFont systemFontOfSize:kDFont];
        _verTitleLab.text = @"验证码登陆";
    }
    return _verTitleLab;
}

- (UITextField *)verTelTextField
{
    if (!_verTelTextField) {
        CGRect rect = CGRectMake(kSpace, CGRectGetMaxY(_verTitleLab.frame) + kSpace, width - kSpace *2, kTextFieldH);
        _verTelTextField = [[UITextField alloc]initWithFrame:rect];
        _verTelTextField.placeholder = @"手机号";
        _verTelTextField.borderStyle = UITextBorderStyleNone;
    }
    return _verTelTextField;
}

- (UIView *)verLine1
{
    if (!_verLine1) {
        CGRect rect = CGRectMake(kSpace, CGRectGetMaxY(_verTelTextField.frame), width - kSpace *2, 1);
        _verLine1 = [[UIView alloc]initWithFrame:rect];
        _verLine1.backgroundColor = [UIColor groupTableViewBackgroundColor];
    }
    return _verLine1;
}

- (UIButton *)verGetCodeBtn
{
    if (!_verGetCodeBtn) {
        CGFloat btnW  = 100;
        _verGetCodeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _verGetCodeBtn.frame = CGRectMake(width - btnW - kSpace , CGRectGetMaxY(_verLine1.frame), btnW, kTextFieldH);
        [_verGetCodeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
        [_verGetCodeBtn setTitleColor:[UIColor lightGrayColor] forState:UIControlStateHighlighted];
        _verGetCodeBtn.titleLabel.font = [UIFont systemFontOfSize:kXFont];
        [_verGetCodeBtn addTarget:self action:@selector(getCode:) forControlEvents:UIControlEventTouchUpInside];
        //_verGetCodeBtn.backgroundColor = [UIColor orangeColor];
    }
    return _verGetCodeBtn;
}

- (UITextField *)verCodeTextField
{
    if (!_verCodeTextField) {
        CGFloat btnW = 100;
        CGRect rect = CGRectMake(kSpace, CGRectGetMaxY(_verTelTextField.frame), width - kSpace*2 - btnW - kSpace , kTextFieldH);
        _verCodeTextField = [[UITextField alloc]initWithFrame:rect];
        _verCodeTextField.placeholder = @"验证码";
        _verCodeTextField.borderStyle = UITextBorderStyleNone;
        
    }
    return _verCodeTextField;
}

- (UIView *)verLine2
{
    if (!_verLine2) {
        CGRect rect = CGRectMake(kSpace, CGRectGetMaxY(_verCodeTextField.frame), width - kSpace *2, 1);
        _verLine2 = [[UIView alloc]initWithFrame:rect];
        _verLine2.backgroundColor = [UIColor groupTableViewBackgroundColor];
    }
    return _verLine2;
}




















@end
