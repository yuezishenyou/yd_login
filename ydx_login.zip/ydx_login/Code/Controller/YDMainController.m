//
//  YDMainController.m
//  ydx_login
//
//  Created by meiyue on 2017/11/3.
//  Copyright © 2017年 meiyue. All rights reserved.
//

#import "YDMainController.h"
#import "YDLoginController.h"

@interface YDMainController ()

//@property (nonatomic, strong) mabaView;

@end

@implementation YDMainController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"登" style:UIBarButtonItemStyleDone target:self action:@selector(login)];
    
}

- (void)login
{
    YDLoginController *login = [[YDLoginController alloc]initWithNibName:@"YDLoginController_iPhone" bundle:nil];
    
    UINavigationController *navc = [[UINavigationController alloc]initWithRootViewController:login];
    
    [self presentViewController:navc animated:YES completion:nil];
    
}













@end
